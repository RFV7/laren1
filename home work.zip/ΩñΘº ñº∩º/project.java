package homework;

public class project {

	public static void main(String[] args) {
		
		
int pex [][] = 
{{ 1, 3 , 2} ,
{200, 100},
{60 , 50 ,70}};
		
  for (int i = 0; i < pex.length; i++){
	           for (int j=0;j < pex[i].length; j++) {
	            	for (int x=0;x < pex[i].length -j -1; x++) {
	            		
	            		if (pex[i][x] > pex[i] [x +1] ) {
	            			int ful = pex[i] [x];
	            			pex [i][x] =pex [i][x+1];
	            			pex [i][x+1] =ful;
	            		}
	            	}
		}				
}	for (int i=0; i<pex.length; i++) {
            for (int x=0;x < pex[i].length; x++) 
			System.out.print(pex[i][x]+"\t");
			System.out.println();
		}
		System.out.println();
		System.out.println(pex[1][1]);

}
}
   

